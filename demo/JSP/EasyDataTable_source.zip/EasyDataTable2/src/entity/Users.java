package entity;

import java.util.ArrayList;
import java.util.List;

import com.google.gson.Gson;

public class Users {
	private int id;
	private String name;
	private String info;
	
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getInfo() {
		return info;
	}
	public void setInfo(String info) {
		this.info = info;
	}
	public Users(int id, String name, String info) {
		super();
		this.id = id;
		this.name = name;
		this.info = info;
	}
	public Users() {
		super();
	}
	
	public static void main(String[] args) {
		
		List list=new ArrayList();
		
		list.add(new String[]{"a","b","c"});
		list.add(new String[]{"a1","b1","c1"});
		list.add(new String[]{"a2","b2","c2"});
		System.out.println(new Gson().toJson(list));
		
	}
	
}
